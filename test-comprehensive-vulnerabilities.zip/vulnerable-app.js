// Test file with various security issues for comprehensive scoring
const express = require('express');
const app = express();

// Critical: SQL Injection vulnerability
app.get('/users', (req, res) => {
  const query = "SELECT * FROM users WHERE id = " + req.query.id;
  db.query(query, (err, results) => {
    res.json(results);
  });
});

// Critical: eval() usage
app.post('/calculate', (req, res) => {
  const result = eval(req.body.expression); // Dangerous code execution
  res.json({ result });
});

// High: XSS vulnerability
app.get('/profile', (req, res) => {
  const html = "<h1>Welcome " + req.query.name + "</h1>";
  res.send(html);
});

// Medium: Hardcoded credentials
const dbConfig = {
  host: 'localhost',
  user: 'admin',
  password: 'admin123', // Hardcoded password
  database: 'myapp'
};

// Medium: Insecure random number generation
function generateToken() {
  return Math.random().toString(36); // Not cryptographically secure
}

// Low: Path traversal potential
app.get('/files', (req, res) => {
  const filename = req.query.file;
  res.sendFile(__dirname + '/uploads/' + filename);
});

// High: Command injection
app.post('/backup', (req, res) => {
  const cmd = 'tar -czf backup.tar.gz ' + req.body.path;
  require('child_process').exec(cmd, (error, stdout) => {
    res.json({ status: 'backup created' });
  });
});

// Critical: Another eval in different context
const processUserCode = (code) => {
  return eval("(" + code + ")");
};

module.exports = app;
