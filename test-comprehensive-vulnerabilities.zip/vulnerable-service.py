import hashlib
import subprocess
import random
import os
import pickle

# Critical: Command injection vulnerability
def backup_database(db_name):
    cmd = f"mysqldump -u root -p {db_name} > backup.sql"
    subprocess.call(cmd, shell=True)  # Dangerous shell execution

# Critical: Pickle deserialization
def load_user_data(data):
    return pickle.loads(data)  # Arbitrary code execution possible

# High: SQL injection in Python
def get_user(user_id):
    query = f"SELECT * FROM users WHERE id = {user_id}"
    return execute_query(query)

# High: Hardcoded secret key
SECRET_KEY = "my-super-secret-key-12345"

# Medium: Weak random number generation for security
def generate_session_id():
    return str(random.randint(1000000, 9999999))

# Medium: Path traversal vulnerability
def read_file(filename):
    with open(f"/uploads/{filename}", 'r') as f:
        return f.read()

# Low: Information disclosure
def debug_info():
    return {
        "server": "production-server-001",
        "version": "1.2.3",
        "debug": True
    }

# Critical: eval() usage
def calculate_expression(expr):
    return eval(expr)  # Code injection vulnerability

# High: Insecure hash algorithm
def hash_password(password):
    return hashlib.md5(password.encode()).hexdigest()

class UserManager:
    def __init__(self):
        self.admin_password = "admin123"  # Hardcoded credential
    
    def authenticate(self, username, password):
        # Timing attack vulnerability
        if username == "admin" and password == self.admin_password:
            return True
        return False
