// Test file with actual security vulnerabilities
const express = require('express');
const app = express();

// Vulnerability 1: Hardcoded credentials
const API_KEY = "sk-1234567890abcdef";
const PASSWORD = "admin123";

// Vulnerability 2: Code injection via eval
app.get('/eval', (req, res) => {
    const userInput = req.query.code;
    eval(userInput); // Dangerous!
    res.send('Code executed');
});

// Vulnerability 3: XSS vulnerability
app.get('/message', (req, res) => {
    const message = req.query.msg;
    res.send(`<div>${message}</div>`); // XSS vulnerable
});

// Vulnerability 4: Using Math.random for security
function generateToken() {
    return Math.random().toString(36);
}

// Vulnerability 5: SQL injection potential
app.get('/user', (req, res) => {
    const query = `SELECT * FROM users WHERE id = ${req.query.id}`;
    // SQL injection vulnerable
});

module.exports = app;
