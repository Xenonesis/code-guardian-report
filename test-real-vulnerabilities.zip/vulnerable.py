#!/usr/bin/env python3
"""
Test Python file with security vulnerabilities
"""
import os
import subprocess
import pickle

# Vulnerability 1: Hardcoded credentials
API_SECRET = "secret123"
DB_PASSWORD = "admin_password"

def execute_command(user_input):
    """Vulnerability 2: Command injection"""
    subprocess.call(user_input, shell=True)  # Dangerous!

def process_data(serialized_data):
    """Vulnerability 3: Insecure deserialization"""
    return pickle.loads(serialized_data)  # Dangerous!

def eval_expression(expr):
    """Vulnerability 4: Code injection"""
    return eval(expr)  # Dangerous!

class UserAuth:
    def __init__(self):
        # Vulnerability 5: Weak random generation
        import random
        self.session_id = str(random.randint(1000, 9999))
    
    def login(self, username, password):
        # Vulnerability 6: SQL injection potential
        query = f"SELECT * FROM users WHERE username='{username}' AND password='{password}'"
        return query

if __name__ == "__main__":
    print("Vulnerable Python application")
    auth = UserAuth()
    result = auth.login("admin", "test'--")
    print(result)
